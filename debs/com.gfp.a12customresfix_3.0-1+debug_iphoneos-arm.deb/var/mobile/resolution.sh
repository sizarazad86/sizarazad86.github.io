#!/bin/bash
iofbres 2688 1242